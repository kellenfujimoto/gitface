from distutils.core import setup
setup(name='gitface', version='0.1', py_modules=['source'])